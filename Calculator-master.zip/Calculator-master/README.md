# Calculator
This is a practical work on the subject of Introduction to IT.
This is a calculator. It can perform addition, subtraction, multiplication, division and exponentiation. Python packages were used: PyQt5
