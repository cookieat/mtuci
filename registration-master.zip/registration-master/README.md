# registration
This is a practical work on the subject of Introduction to IT. This is a web application with a registration form. Python packages were used: flask and psycopg2
