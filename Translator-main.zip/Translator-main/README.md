# second_it
# Translate and analyze text with Azure Cognitive Services
This is a practical work on the subject of Introduction to IT. 
This is a translator from one language to another. Python packages were used: Flask
