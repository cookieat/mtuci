# python-bot
This is a practical work on the subject of Introduction to IT. 
This is a chat bot for telegram in python.
It shows the schedule of our study group. 
Python packages were used:pyTelegramBotAPI, psycopg2, datetime
